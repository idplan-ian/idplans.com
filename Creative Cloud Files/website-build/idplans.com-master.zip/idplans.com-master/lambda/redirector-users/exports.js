module.exports = {


	"context": {
		"stage": "prod",
		"http-method": "PUT"
	},
	"body-json": {
		"username": "lbeaz",
		"active": "1",
		"ver3": false,
		"ver4": true
	}

};