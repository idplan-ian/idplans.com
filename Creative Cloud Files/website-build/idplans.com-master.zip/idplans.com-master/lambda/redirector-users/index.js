exports.handler = function (event, context, callback) {

	try {
		//var stage = event.context.stage;
		var method = event.context["http-method"];
		var data = event["body-json"];

		switch (method.toUpperCase()) {
			case "GET":
				getUsers(callback);
				break;
			case "POST":
				addUser(data, callback);
				break;
			case "PUT":
				editUser(data, callback);
				break;
			case "DELETE":
				deleteUser(data, callback);
				break;
			default:
				callback("Bad Request: No Valid Method.", null);
				break;
		}

	}
	catch (e) {
		callback("Bad Request: " + e.message, null);
	}
};

var editUser = function (userdata, callback) {
	try {

		var haserr = false;
		var errmsg = "";
		if (!userdata) {
			haserr = true;
			errmsg = "User data appears invalid.";
		}
		if (!userdata.username || userdata.username.length < 1) {
			haserr = true;
			errmsg = "Username appears invalid.";
		}
		if (!userdata.active || (userdata.active !== "0" && userdata.active !== "1")) {
			haserr = true;
			errmsg = "User active flag appears invalid.";
		}
		if (userdata.ver3 !== true && userdata.ver3 !== false) {
			haserr = true;
			errmsg = "User ver3 flag appears invalid.";
		}
		if (userdata.ver4 !== true && userdata.ver4 !== false) {
			haserr = true;
			errmsg = "User ver4 flag appears invalid.";
		}
		if (userdata.ver4Kimco !== true && userdata.ver4Kimco !== false) {
			haserr = true;
			errmsg = "User ver4 flag appears invalid.";
		}
		if (userdata.ver3 == userdata.ver4 == userdata.verKimco) {
			haserr = true;
			errmsg = "ver3 and ver4 and ver4Kimco cannot be equal.";
		}

		if (!haserr) {

			var AWS = require("aws-sdk");
			var s3 = new AWS.S3();
			var fs = require('fs');

			var params = {
				Bucket: 'www.idplans.com',
				Key: 'json/webusers.json'
			};

			s3.getObject(params, function (err, filedata) {

				if (!err) {
					var users = [];
					try {
						users = JSON.parse(filedata.Body.toString("ascii"));
					}
					catch (e) {
						err = e.message;
					}

					if(!err){
						users.forEach(function (user, index) {
							if (user.username === userdata.username) {
								users[index] = userdata;
							}
						});

						var params = {
							Bucket: 'www.idplans.com',
							Key: 'json/webusers.json',
							Body: JSON.stringify(users)
						};

						s3.putObject(params, function (err, putdata) {
							callback(err, users);
						});
					}
					else{
						callback("Bad Request: " + err, null);
					}
				}
				else {
					console.log(err);
					callback("Bad Request: " + err, null);
				}
			});
		}
		else {
			callback("Bad Request: " + errmsg, null);
		}

	}
	catch (e) {
		callback("Bad Request: " + e.message, null);
	}
};

var getUsers = function (callback) {
	try {

		var AWS = require("aws-sdk");
		var s3 = new AWS.S3();
		var fs = require('fs');

		var params = {
			Bucket: 'www.idplans.com',
			Key: 'json/webusers.json'
		};

		s3.getObject(params, function (err, filedata) {

			if (!err) {
				var users = null;
				try {
					users = JSON.parse(filedata.Body.toString("ascii"));
				}
				catch (e) {
					err = e.message;
				}

				callback(err, users);
			}
			else {
				callback("Bad Request: " + err, null);
			}
		});
	}
	catch (e) {
		callback("Bad Request: " + e.message, null);
	}
};

var addUser = function (userdata, callback) {
	try {

		var haserr = false;
		var errmsg = "";
		if (!userdata) {
			haserr = true;
			errmsg = "User data appears invalid.";
		}
		if (!userdata.username || userdata.username.length < 1) {
			haserr = true;
			errmsg = "Username appears invalid.";
		}
		if (!userdata.active || (userdata.active !== "0" && userdata.active !== "1")) {
			haserr = true;
			errmsg = "User active flag appears invalid.";
		}
		if (userdata.ver3 !== true && userdata.ver3 !== false) {
			haserr = true;
			errmsg = "User ver3 flag appears invalid.";
		}
		if (userdata.ver4 !== true && userdata.ver4 !== false) {
			haserr = true;
			errmsg = "User ver4 flag appears invalid.";
		}
		if (userdata.ver4Kimco !== true && userdata.ver4Kimco !== false) {
			haserr = true;
			errmsg = "User ver4 flag appears invalid.";
		}
		if (userdata.ver3 == userdata.ver4 == userdata.ver4Kimco) {
			haserr = true;
			errmsg = "ver3 and ver4 and ver4Kimco cannot be equal.";
		}

		if (!haserr) {

			var AWS = require("aws-sdk");
			var s3 = new AWS.S3();
			var fs = require('fs');

			var params = {
				Bucket: 'www.idplans.com',
				Key: 'json/webusers.json'
			};

			s3.getObject(params, function (err, filedata) {

				if (!err) {
					var users = [];
					try {
						users = JSON.parse(filedata.Body.toString("ascii"));
					}
					catch (e) {
						err = e.message;
					}

					users.forEach(function (user, index) {
						if (user.username.toLowerCase() === userdata.username.toLowerCase()) {
							err = "The username is already taken.";
						}
					});

					if(!err){
						users.push(userdata);

						var params = {
							Bucket: 'www.idplans.com',
							Key: 'json/webusers.json',
							Body: JSON.stringify(users)
						};

						s3.putObject(params, function (err, putdata) {
							callback(err, users);
						});

					}
					else{
						callback("Bad Request: " + err, null);
					}

				}
				else {
					console.log(err);
					callback("Bad Request: " + err, null);
				}
			});
		}
		else {
			callback("Bad Request: " + errmsg, null);
		}

	}
	catch (e) {
		callback("Bad Request: " + e.message, null);
	}
};

var deleteUser = function (userdata, callback) {
	try {

		var haserr = false;
		var errmsg = "";
		if (!userdata) {
			haserr = true;
			errmsg = "User data appears invalid.";
		}
		if (!userdata.username || userdata.username.length < 1) {
			haserr = true;
			errmsg = "Username to delete appears invalid.";
		}

		if (!haserr) {

			var AWS = require("aws-sdk");
			var s3 = new AWS.S3();
			var fs = require('fs');

			var params = {
				Bucket: 'www.idplans.com',
				Key: 'json/webusers.json'
			};

			s3.getObject(params, function (err, filedata) {

				if (!err) {
					var users = [];
					try {
						users = JSON.parse(filedata.Body.toString("ascii"));
					}
					catch (e) {
						err = e.message;
					}

					if(!err){
						var len = users.length;
						users.forEach(function (user, index) {
							if (user.username === userdata.username) {
								users.splice(index, 1);
							}
						});
						if(users.length < len){
							var params = {
								Bucket: 'www.idplans.com',
								Key: 'json/webusers.json',
								Body: JSON.stringify(users)
							};

							s3.putObject(params, function (err, putdata) {
								callback(err, users);
							});
						}
						else{
							callback("Bad Request: The user could not be found or failed to delete.", null);
						}
					}
					else{
						callback("Bad Request: " + err, null);
					}
				}
				else {
					callback("Bad Request: " + err, null);
				}
			});
		}
		else {
			callback("Bad Request: " + errmsg, null);
		}

	}
	catch (e) {
		callback("Bad Request: " + e.message, null);
	}
};








