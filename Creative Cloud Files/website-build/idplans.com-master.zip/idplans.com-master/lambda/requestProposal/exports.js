module.exports = {

	"body-json":{
		"name": "myn&a m#e",
		"company": "mycompany",
		"phone": "1231231234",
		"id": "12345-abcdef"
	},
	context: {
		stage: "prod"
	}

};