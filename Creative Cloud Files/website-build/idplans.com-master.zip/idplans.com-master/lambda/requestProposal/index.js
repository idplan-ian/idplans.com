
var aws = require('aws-sdk');
var moment = require("moment");
var _ = require("underscore");
var nodemailer = require("nodemailer");

exports.handler = function(event, context, callback) {

	var err = false;
	var errmsgs = [];
	var stage = event.context.stage; // prod || dev (only prod for now)
	var data = event["body-json"];

	if(stage){
		// booyah
	}

	/*
	 SMTP Username: AKIAID4EWJVLIK6S4LMQ
	 SMTP Password: AuSaFCQQlzau4Kn18iwQdRalI17bUuSylIiDNynSFdnQ

	  {
	 "proposalType":proposalType,
	 "companyName":company,
	 "propertyName":name,
	 "phone":phone,
	 "email":email,
	 "message":message,
	 "properties":properties
	 }
	 */

	try{
		if(!data.proposalType || (data.proposalType != "sp" && data.proposalType != "rpm")){
			err = true;
			errmsgs.push("Proposal Type is required (sp/rpm).");
		}
		if(!data.companyName || data.companyName.length < 1){
			err = true;
			errmsgs.push("Company Name is required.");
		}
		if(!data.propertyName || data.propertyName.length < 1){
			err = true;
			errmsgs.push("Property Name is required.");
		}
		if(!data.phone || data.phone.length < 10){
			err = true;
			errmsgs.push("Phone is required.");
		}
		if(!data.email || data.email.length < 4){
			err = true;
			errmsgs.push("Email is required.");
		}
		if(!data.message){
			data.message = "";
		}
		if(!data.properties){
			data.properties = [];
		}

		if(!err){

			var html = "Hello,<br/><br/>There was a new proposal request form submitted " +
				"on the ID Plans website. The information submitted with the request is below.<br/><br/>" +
				"Request Type: " + data.proposalType.toUpperCase() + "<br/>" +
				"Company Name: " + data.companyName + "<br/>" +
				"Property Name: " + data.propertyName + "<br/>" +
				"Phone: " + data.phone + "<br/>" +
				"Email: " + data.email + "<br/>" +
				"Message:" + data.message + "<br/><br/>" +
				((data.properties.length<2)?("Property"):("Properties")) + " details:<br/>";

			_.each(data.properties, function(p){
				html += "----------------------<br/>" +
				"Name: " + p.name + "<br/>" +
				"Location: " + p.city + ", " + p.state + "<br/>" +
				"GLA: " + p.gla + "<br/>" +
				"Type: " + p.type + "<br/>";

				if(data.proposalType=="sp"){
					html += "Unit: " + p.unit + "<br/>Occupancy Status: " + p.occupancy + "<br/>";
				}
			});

			html += "<br/><br/>Thanks!";

			var smtpConfig = {
				host: 'email-smtp.us-east-1.amazonaws.com',
				port: 465,
				secure: true,
				auth: {
					user: 'AKIAIYR2GL7PKHJQA6WA',
					pass: 'AoMrobOi6bVZ260fyM+gxIdDT+EpD+rEI5noyjM1D5P1'
				}
			};
			var mailOptions = {
				"subject": "A new proposal request from www.idplans.com ",
				"type":"text/html",
				"html": html,
				"to":"support@idplans.com",
				"from":"www-contact-form@idplans.com"
			};

			var transporter = nodemailer.createTransport(smtpConfig);
			transporter.sendMail(mailOptions, function (err, options) {
				if (err) {
					callback("Bad Request: " + err, null);
				}
				else {
					console.log(options);
					callback(null, {"success":true});
				}
			});

		}
		else{
			callback("Bad Request: " + errmsgs.join(", "), null);
		}
	}
	catch(e){
		callback("Internal Error: " + e.message, null);
	}

};