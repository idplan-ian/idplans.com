var redirector = {


	authorize: function(key, callback){
		var data = {
			"key": key
		};

		$.ajax
		({
			type: "POST",
			url: 'https://r8kajiq608.execute-api.us-east-1.amazonaws.com/prod/redirector/authorize',
			dataType: 'json',
			data: JSON.stringify(data),
			contentType: "application/json",
			success: function (data, statusText, event) {
				if(event.status==200) {
					callback(null, data);
				}
				else{
					callback("Status not 200.", null);
				}
			},
			error: function(xhr, status, err){
				var tmp = JSON.parse(xhr.responseText);
				callback(tmp.errorMessage, null);
			}
		});

	},

	getUsers: function(callback){
		var s = moment().valueOf();
		$.get("http://www.idplans.com/json/webusers.json?"+s, function(data){

			var users = [];
			try{
				users = JSON.parse(data);
				callback(null, users);
			}
			catch(e){
				callback("Error retrieving user data.", null);
			}

		}).fail(function(e){
			console.log(e);
			callback("Error retrieving user data.", null);
		});
	},

	addUser: function(userObj, callback){

		var err = true;
		if(!_.isEmpty(userObj)){
			if(_.has(userObj, "username") && !_.isEmpty(userObj.username)){
				if(_.has(userObj, "active") && (userObj.active == "0" || userObj.active == "1")){
					if(_.has(userObj, "ver3")){
						if(_.has(userObj, "ver4")){
							if(_.has(userObj, "ver4Kimco")){
								err = false;
							}
						}
					}
				}
			}
		}

		if(!err){
			try{
				$.ajax
				({
					type: "POST",
					url: 'https://r8kajiq608.execute-api.us-east-1.amazonaws.com/prod/redirector/users',
					dataType: 'json',
					data: JSON.stringify(userObj),
					contentType: "application/json",
					success: function (data, statusText, event) {
						if(event.status==200) {
							callback(null, data);
						}
						else{
							callback("Status not 200.", null);
						}
					},
					error: function(xhr, status, err){
						var tmp = JSON.parse(xhr.responseText);
						callback(tmp.errorMessage, null);
					}
				});
			}
			catch(e){
				console.log(e);
				callback(e.message, null);
			}
		}
		else{
			callback("Invalid user object.", null);
		}

	},

	updateUser: function(userObj, newver, callback){

		var err = true;
		if(!_.isEmpty(userObj)){
			if(_.has(userObj, "username") && !_.isEmpty(userObj.username)){

				if(_.has(userObj, "active") && (userObj.active == "0" || userObj.active == "1")){

					if(_.has(userObj, "slug")){
						delete userObj.slug;
					}

					if(_.has(userObj, "ver3")){
						if(newver == 3){
							userObj.ver3 = true;
							userObj.ver4 = false;
							userObj.ver4Kimco = false;
						}
						if(_.has(userObj, "ver4")){
							if(newver == 4){
								userObj.ver3 = false;
								userObj.ver4 = true;
								userObj.ver4Kimco = false;
							}

							if(_.has(userObj, "ver4Kimco")){
								if(newver == '4k'){
									userObj.ver3 = false;
									userObj.ver4 = false;
									userObj.ver4Kimco = true;
								}
								err = false;
							}
						}
					}
				}
			}
		}

		if(!err){
			try{
				$.ajax
				({
					type: "PUT",
					url: 'https://r8kajiq608.execute-api.us-east-1.amazonaws.com/prod/redirector/users',
					dataType: 'json',
					data: JSON.stringify(userObj),
					contentType: "application/json",
					success: function (data, statusText, event) {
						if(event.status==200) {
							callback(null, data);
						}
						else{
							callback("Status not 200.", null);
						}
					},
					error: function(xhr, status, err){
						var tmp = JSON.parse(xhr.responseText);
						callback(tmp.errorMessage, null);
					}
				});
			}
			catch(e){
				console.log(e);
				callback(e.message, null);
			}
		}
		else{
			callback("Invalid user object.", null);
		}

	},

	deleteUser: function(userObj, callback){
		try{
			$.ajax
			({
				type: "DELETE",
				url: 'https://r8kajiq608.execute-api.us-east-1.amazonaws.com/prod/redirector/users',
				dataType: 'json',
				data: JSON.stringify(userObj),
				contentType: "application/json",
				success: function (data, statusText, event) {
					if(event.status==200) {
						callback(null, data);
					}
					else{
						callback("Status not 200.", null);
					}
				},
				error: function(xhr, status, err){
					var tmp = JSON.parse(xhr.responseText);
					callback(tmp.errorMessage, null);
				}
			});
		}
		catch(e){
			console.log(e);
			callback(e.message, null);
		}
	},

	clone: function(obj){
		var tmp = null;
		try{
			tmp = JSON.stringify(obj);
			tmp = JSON.parse(tmp);
		}
		catch(e){
			console.log("clone:", e.message);
		}
		return tmp;
	}

};