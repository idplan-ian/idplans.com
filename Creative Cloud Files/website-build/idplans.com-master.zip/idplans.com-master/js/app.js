var login = function() {

    $(".error-display").hide();
    $(".spinner").show();
    $(".msg-display").show();

    try {
        //console.log("login");
        var u = $("#username").val();
        var p = $("#password").val();
        var errors = [];

        if (!u || u.length < 1) {
            errors.push("Username is required.");
        }
        if (!p || p.length < 1) {
            errors.push("Password is required");
        }

        if (errors.length > 0) {
            $(".error-display").show();
            $(".error-text").html(errors.join("<br/>"));
            $(".msg-display").hide();
            $(".spinner").hide();
        } else {
            var s = moment().valueOf();
            $.get("/json/webusers.json?" + s, function(userdata) {

                var data = [];
                try {
                    data = JSON.parse(userdata);
                } catch (e) {
                    //
                    data = userdata;
                }

                if (data.length > 0) {
                    var user = null;
                    for (var i = 0; i < data.length; i++) {
                        if (data[i].username == u) {
                            user = data[i];
                        }
                    }

                    if (!user) {
                        $(".error-display").show();
                        $(".error-text").html("Username not found.");
                        $(".msg-display").hide();
                        $(".spinner").hide();
                    } else {

                        var npw = "";
                        var pwc = "";

                        for (var ii = 0; ii < p.length; ii++) {
                            npw = npw + p.substr(ii, 1).charCodeAt(0).toString();
                            pwc = pwc + p.substr(ii, 1).charCodeAt(0).toString().length;
                        }
                        npw = npw + ":" + pwc;

                        if (user.ver4Kimco && user.ver4Kimco === true) {
                            window.location.href = "http://kimco.idplans.com/rpm/#/login?uid=" + u + "&redirect-token=" + npw;
                        } else if (user.ver4 === true) {
                            window.location.href = "http://v4-prod.idplans.com/rpm/#/login?uid=" + u + "&redirect-token=" + npw;
                        } else if (user.ver3 == true) {
                            window.location.href = "http://webapp.idplans.com/?fromv2=true&v2uid=" + u + "&v2token=" + npw;
                        } else {
                            $(".error-display").show();
                            $(".error-text").html("User not authorized for RPM.");
                            $(".msg-display").hide();
                            $(".spinner").hide();
                        }
                    }
                } else {
                    $(".error-display").show();
                    $(".error-text").html("Error retrieving user objects.");
                    $(".msg-display").hide();
                    $(".spinner").hide();
                }
            }).error(function() {
                $(".error-display").show();
                $(".error-text").html("Error retrieving user data.");
                $(".msg-display").hide();
                $(".spinner").hide();
            });
        }
    } catch (e) {
        $(".error-display").show();
        $(".error-text").html(e.message);
        $(".msg-display").hide();
        $(".spinner").hide();
        //console.log(e);
    }

};

var demologin = function() {
    $("#username").val("webdemo");
    $("#password").val("webdemo");
    login();
};

var remoteDemoLogin = function() {
    //console.log("remotedemologin");
    window.location.href = "/index.html?demologin=true";
};

var getInTouch = function() {

        $(".getInTouchSuccess").hide();
        $(".getInTouchError").hide();
        $(".contact-spinner").show();
        $(".contact-btn").hide();

		//validation form upper form
        var isValid = true;
        var errors = [];
        $(".upperform").find(":text, select,input[type='email'],input[type='number']").each(function() {
            if ($(this).val() === "" && $(this).prop("type") != "email" && $(this).prop("type") != "number") {
                console.log("Empty Fields!!");
                errors.push($(this).data("errtext"));
                isValid = false;
            }
            if ($(this).prop("type") == "email") {
                var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
                var validatemail = re.test($(this).val());
                if (!validatemail) {
                    errors.push($(this).data("errtext"));
                    isValid = false;
                }
            }
            if ($(this).prop("type") == "number") {
                if ($(this).val().length < 9) {
                    errors.push($(this).data("errtext"));
                    isValid = false;
                }
            }
        });
		//== properties start
		var arePropertiesValid = true;
        $(".properties").find(":text, select,input[type='email'],input[type='number']").each(function() {
            if ($(this).val() === "") {
                arePropertiesValid = false;
            }
        });
		if(!arePropertiesValid){
			errors.push("Property details are mandatory.");
		}
		//== properties end
		
		errors = errors.filter(function( element ) {
		   return element !== undefined;
		});
		
        if (!isValid) {
            $(".contact-spinner").hide();
            $(".contact-btn").show();
            $(".getInTouchError").show();
            $(".getInTouchErrorText").html(errors.join("<br/>"));
        } else {
            var data = {
                "name": $("#git_name").val(),
                "company": $("#git_company").val(),
                "phone": $("#git_phone").val(),
                "email": $("#git_email").val(),
                "comments": $("#rp_message").val(),
                "inquiryNature": $("#inquiry_nature option:selected").val()
            };
			// https://r8kajiq608.execute-api.us-east-1.amazonaws.com/prod/request-proposal

            $.ajax({
					type: "POST",
					url: 'https://r8kajiq608.execute-api.us-east-1.amazonaws.com/prod/contact',
					dataType: 'json',
					data: JSON.stringify(data),
					contentType: "application/json"
				}).success(function(data) {
						if (data.success && data.success == true) {
							//alert("Your message was sent, we'll get back with you very soon.");
							$(".getInTouchSuccess").show();
						} else {
							$(".getInTouchError").show();
							$(".getInTouchErrorText").html(data.errorMessage);
						}
						$("#ssp_proposal,#rpm_proposal").find(":text,input[type='email'],input[type='number']").each(function() {
							$(this).val("");
						});

						$(".contact-spinner").hide();
						$(".contact-btn").show();
				}).fail(function(xhr, status, err) {
						$(".contact-spinner").hide();
						$(".contact-btn").show();
						var tmp = JSON.parse(xhr.responseText);
						$(".getInTouchError").show();
						$(".getInTouchErrorText").html(tmp.errorMessage);
				});
            }
           
}

        var requestProposal = function() {

            // $(".requestProposalSuccess").hide();
            // $(".requestProposalError").hide();
            // $(".proposal-spinner").show();
            // $(".proposal-btn").hide();

            $(".getInTouchSuccess").hide();
            $(".getInTouchError").hide();
            $(".contact-spinner").show();
            $(".contact-btn").hide();

            //console.log("req pro");

            try {
                //
                var propertyName = $("#rp_PropertyName").val();
                var city = $("#rp_City").val();
                var state = $("#rp_State").val();
                var type = $("#rp_type option:selected").val();
                var message = $("#rp_message").val();

                var errors = [];

                if (propertyName.length < 1) {
                    errors.push("Property name is required.");
                }
                if (city.length < 1) {
                    errors.push("City is required.");
                }
                if (state.length < 1) {
                    errors.push("State is required.");
                }
                if (type == "0") {
                    errors.push("Industry type is required.");
                }

                //console.log(type);

                if (errors.length < 1) {
                    var data = {
                        "propertyName": propertyName,
                        "city": city,
                        "state": state,
                        "type": type,
                        "message": message
                    };

                    //https://r8kajiq608.execute-api.us-east-1.amazonaws.com/prod/request-proposal

                    $.ajax({
                        type: "POST",
                        url: 'https://r8kajiq608.execute-api.us-east-1.amazonaws.com/prod/request-proposal',
                        dataType: 'json',
                        data: JSON.stringify(data),
                        contentType: "application/json",
                        success: function(data) {
                            //console.log("s",data);
                            if (data.success && data.success == true) {
                                //alert("Your message was sent, we'll get back with you very soon.");
                                $(".requestProposalSuccess").show();
                            } else {
                                //console.log("1",data);
                                $(".contact-spinner").hide();
                                $(".contact-btn").show();
                                $(".requestProposalError").show();
                                $(".requestProposalErrorText").html(data.errorMessage);
                            }

                            $("#rp_PropertyName").val("");
                            $("#rp_City").val("");
                            $("#rp_State").val("");
                            $("#rp_type").selectedIndex = 0;
                            $("#rp_message").val("");

                            $(".contact-spinner").hide();
                            $(".contact-btn").show();
                        },
                        fail: function(xhr, status, err) {
                            //console.log("f",xhr);
                            $(".contact-spinner").hide();
                            $(".contact-btn").show();
                            var tmp = JSON.parse(xhr.responseText);
                            $(".requestProposalError").show();
                            $(".requestProposalErrorText").html(tmp.errorMessage);
                        },
                        error: function(xhr, status, err) {
                            //console.log("e",xhr);
                            $(".contact-spinner").hide();
                            $(".contact-btn").show();
                            var tmp = JSON.parse(xhr.responseText);
                            $(".requestProposalError").show();
                            $(".requestProposalErrorText").html(tmp.errorMessage);
                        }
                    });
                } else {
                    $(".contact-spinner").hide();
                    $(".contact-btn").show();
                    $(".requestProposalError").show();
                    $(".requestProposalErrorText").html(errors.join("<br/>"));
                }
            } catch (e) {
                $(".contact-spinner").hide();
                $(".contact-btn").show();
                $(".requestProposalError").show();
                $(".requestProposalErrorText").html(e.message);
            }

        };

        var playVideo = function(video) {

            if (video == "demo") {
                $(".video-player-bg").height($(document).height() + "px");
                $(".video-player-bg").show();

                var top = $(document).height() - $(window).height();
                $(".video-player").height(($(window).height() - 5) + "px");
                $(".video-player").show();

                $("video-container").height(($(window).height() - 5) + "px");
                $("video-container").width("100%");

                $(".video-container").attr("src", video + "/index.html");
                $(".video-container").show();
            } else {
                window.open("spdemo/demo-profile.pdf");
            }

        };

        var closeVideo = function() {
            $(".video-container").attr("src", "");
            $(".video-player").hide();
            $(".video-player-bg").hide();
            $(".video-container").hide();
        };