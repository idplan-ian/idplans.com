var fs = require("fs");
var _ = require("underscore");

var importFromCsv = function () {
	var u = fs.readFile("webusers.csv", "utf8", function (err, data) {


		if (!err) {


			var records = data.split("\n");
			var users = [];

			//console.log(records[0]);
			//console.log(records[0].split(","));

			for (var i = 0; i < records.length; i++) {

				//console.log(records[i]);
				var usr = records[i].split(",");
				//console.log(usr);

				var user = {
					"username": usr[0],
					"active": usr[1],
					"ver3": ((parseInt(usr[2]) == 1) ? (true) : (false)),
					"ver4": ((parseInt(usr[3]) == 1) ? (true) : (false))
				};

				//console.log(user);
				users.push(user);

			}

			fs.writeFile("webusers.json", JSON.stringify(users), function (err) {
				if (err) {
					console.log(err);
				}

				else {
					console.log("done");
				}

			})

		}
		else {
			console.log(err);
		}

	});
};

var exportBadUsers = function(){


	var userlist = require("./webusers.json");
	var newuserlist = [];

	_.each(userlist, function(user){
		if(user.ver3 == true || user.ver4 == true){
			newuserlist.push(user);
		}
	});

	fs.writeFileSync("./js/new-users.json", JSON.stringify(newuserlist), "utf8");

};

exportBadUsers();

//console.log(users);
